# Meeeshow V1 + Admin Panel

## Admin Panel
Open `admin.html`.

Demo login:
- Username: `admin`
- Password: `123456`

Features:
- Dashboard
- Add/edit/delete products
- Price, old price, discount and stock
- Product search
- Orders view
- Customers view
- Categories
- Coupons
- Store settings
- COD remains disabled
- Product catalogue is saved in browser localStorage and is read by `index.html` on the same browser/origin.

## Storefront
Open `index.html`.

Note: This is a frontend prototype. Real production features still require a backend, database, secure authentication, real image storage, order persistence, and a payment gateway such as Razorpay. Do not use the demo admin password in production.
